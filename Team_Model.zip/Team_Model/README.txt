Import Project Team_Model.
Execute TeamModel class; it contains the main method.