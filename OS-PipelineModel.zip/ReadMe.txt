Import Project :  OS-PipelineModel
Execute pipelineModelDemo class ; it contains the main method.
Java version : Minimum 1.7
External Jar file required : commons-lang3-3.1.jar
For initiating first stage enter search key word of visualization folder such as dream, coconut, border, endgame, contact, effect etc and press search button.